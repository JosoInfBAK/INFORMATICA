package TipoDatos;

public class ComponenteLexico {
		
		private String etiqueta;
		
		public ComponenteLexico(String etiqueta) {
			this.etiqueta = etiqueta;
		}
		
		public String getEtiqueta() {
			return this.etiqueta;
		}

		public String toString() {
			return this.etiqueta;
		}
}
