package TipoDatos;

public class Primitivo extends TipoDato {

	public Primitivo(String tipo) {
		super(tipo);
	}
	
	public String toString() {
		return super.toString();
	}
	
}
